document.addEventListener("DOMContentLoaded", function () {

    /* =========================================================
       SIDEBAR / MOBILE MENU
    ========================================================= */

    const sidebar = document.querySelector(".sidebar");
    const menuToggle = document.querySelector(".menu-toggle");
    const overlay = document.querySelector(".sidebar-overlay");

    if (menuToggle && sidebar) {
        menuToggle.addEventListener("click", function () {
            sidebar.classList.toggle("active");

            if (overlay) {
                overlay.classList.toggle("active");
            }
        });
    }

    if (overlay) {
        overlay.addEventListener("click", function () {
            sidebar.classList.remove("active");
            overlay.classList.remove("active");
        });
    }


    /* =========================================================
       CLOSE SIDEBAR ON MOBILE
    ========================================================= */

    const sidebarLinks = document.querySelectorAll(".sidebar a");

    sidebarLinks.forEach(function (link) {

        link.addEventListener("click", function () {

            if (window.innerWidth <= 991) {

                sidebar.classList.remove("active");

                if (overlay) {
                    overlay.classList.remove("active");
                }

            }

        });

    });


    /* =========================================================
       PASSWORD SHOW / HIDE
    ========================================================= */

    const passwordToggles =
        document.querySelectorAll(".password-toggle");


    passwordToggles.forEach(function (toggle) {

        toggle.addEventListener("click", function () {

            const input =
                this.parentElement.querySelector(
                    'input[type="password"], input[type="text"]'
                );


            if (!input) {
                return;
            }


            if (input.type === "password") {

                input.type = "text";

                this.classList.add("active");

            } else {

                input.type = "password";

                this.classList.remove("active");

            }

        });

    });


    /* =========================================================
       CURRENT YEAR
    ========================================================= */

    const yearElements =
        document.querySelectorAll(".current-year");


    yearElements.forEach(function (element) {

        element.textContent =
            new Date().getFullYear();

    });


    /* =========================================================
       MAP VARIABLES
    ========================================================= */

    let map = null;

    let marker = null;

    let currentLatitude = null;

    let currentLongitude = null;


    const mapElement =
        document.getElementById("map");


    const latitudeElement =
        document.getElementById("latitude");


    const longitudeElement =
        document.getElementById("longitude");


    const refreshLocationButton =
        document.getElementById("refresh-location");


    /* =========================================================
       DEFAULT LOCATION
       Used when GPS permission is denied/unavailable.
    ========================================================= */

    const DEFAULT_LATITUDE = 27.4924;

    const DEFAULT_LONGITUDE = 77.6737;


    /* =========================================================
       UPDATE COORDINATES
    ========================================================= */

    function updateCoordinates(latitude, longitude) {

        if (latitudeElement) {

            latitudeElement.textContent =
                Number(latitude).toFixed(6);

        }


        if (longitudeElement) {

            longitudeElement.textContent =
                Number(longitude).toFixed(6);

        }

    }


    /* =========================================================
       CREATE GOLD LOCATION ICON
    ========================================================= */

    function createGoldLocationIcon() {

        return L.divIcon({

            className:
                "gold-marker-wrapper",

            html:
                `
                <div class="gold-location-marker"></div>
                `,

            iconSize: [
                28,
                28
            ],

            iconAnchor: [
                14,
                14
            ],

            popupAnchor: [
                0,
                -16
            ]

        });

    }


    /* =========================================================
       INITIALIZE MAP
    ========================================================= */

    function initializeMap(latitude, longitude) {

        if (!mapElement) {

            console.warn(
                "Map element #map was not found."
            );

            return;

        }


        /* =====================================================
           IF MAP ALREADY EXISTS
        ===================================================== */

        if (map !== null) {

            map.setView(
                [
                    latitude,
                    longitude
                ],
                14
            );


            if (marker) {

                marker.setLatLng([
                    latitude,
                    longitude
                ]);

            }


            return;

        }


        /* =====================================================
           CREATE MAP
        ===================================================== */

        map = L.map(
            "map",
            {
                zoomControl: false,

                attributionControl: true
            }
        ).setView(
            [
                latitude,
                longitude
            ],
            14
        );


        /* =====================================================
           DARK CARTO MAP
        ===================================================== */

        const darkMap =
            L.tileLayer(
                "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
                {
                    maxZoom: 19,

                    attribution:
                        "&copy; OpenStreetMap contributors"
                }
            );


        /* =====================================================
           SATELLITE MAP
        ===================================================== */

        const satelliteMap =
            L.tileLayer(
                "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
                {
                    maxZoom: 19,

                    attribution:
                        "Tiles &copy; Esri"
                }
            );


        /* =====================================================
           DEFAULT MAP
        ===================================================== */

        darkMap.addTo(map);


        /* =====================================================
           MAP LAYERS
        ===================================================== */

        const baseMaps = {

            "Dark Map":
                darkMap,

            "Satellite":
                satelliteMap

        };


        L.control.layers(
            baseMaps,
            null,
            {
                position: "topright",

                collapsed: true
            }
        ).addTo(map);


        /* =====================================================
           ZOOM CONTROL
        ===================================================== */

        L.control.zoom({
            position: "topright"
        }).addTo(map);


        /* =====================================================
           GOLD LOCATION MARKER
        ===================================================== */

        const goldIcon =
            createGoldLocationIcon();


        marker =
            L.marker(
                [
                    latitude,
                    longitude
                ],
                {
                    icon: goldIcon
                }
            ).addTo(map);


        /* =====================================================
           LOCATION POPUP
        ===================================================== */

        marker.bindPopup(
            `
            <div class="location-popup">

                <strong>
                    Current Vehicle Location
                </strong>

                <br><br>

                <span>
                    Latitude:
                    ${Number(latitude).toFixed(6)}
                </span>

                <br>

                <span>
                    Longitude:
                    ${Number(longitude).toFixed(6)}
                </span>

            </div>
            `
        );


        /* =====================================================
           OPEN POPUP
        ===================================================== */

        marker.openPopup();


        /* =====================================================
           LOCATION SEARCH
        ===================================================== */

        if (
            typeof GeoSearch !== "undefined" &&
            GeoSearch.OpenStreetMapProvider
        ) {

            const provider =
                new GeoSearch.OpenStreetMapProvider();


            const searchControl =
                new GeoSearch.GeoSearchControl({

                    provider:
                        provider,

                    style:
                        "bar",

                    showMarker:
                        true,

                    retainZoomLevel:
                        false,

                    animateZoom:
                        true,

                    autoClose:
                        true,

                    searchLabel:
                        "Search location..."

                });


            map.addControl(
                searchControl
            );


            /* =================================================
               SEARCH RESULT
            ================================================= */

            map.on(
                "geosearch/showlocation",
                function (result) {

                    if (
                        !result ||
                        !result.location
                    ) {
                        return;
                    }


                    const searchLatitude =
                        result.location.y;


                    const searchLongitude =
                        result.location.x;


                    map.setView(
                        [
                            searchLatitude,
                            searchLongitude
                        ],
                        15
                    );

                }
            );

        }


        /* =====================================================
           FIX MAP SIZE
        ===================================================== */

        setTimeout(
            function () {

                map.invalidateSize();

            },
            300
        );

    }


    /* =========================================================
       SUCCESSFUL GPS LOCATION
    ========================================================= */

    function locationSuccess(position) {

        if (
            !position ||
            !position.coords
        ) {

            locationError({
                message:
                    "Invalid GPS response."
            });

            return;

        }


        currentLatitude =
            position.coords.latitude;


        currentLongitude =
            position.coords.longitude;


        /* Update coordinates */

        updateCoordinates(
            currentLatitude,
            currentLongitude
        );


        /* Create/update map */

        initializeMap(
            currentLatitude,
            currentLongitude
        );

    }


    /* =========================================================
       GPS ERROR
    ========================================================= */

    function locationError(error) {

        console.warn(
            "GPS error:",
            error
        );


        /*
         * Use default location instead
         * of leaving the map blank.
         */

        currentLatitude =
            DEFAULT_LATITUDE;


        currentLongitude =
            DEFAULT_LONGITUDE;


        updateCoordinates(
            currentLatitude,
            currentLongitude
        );


        initializeMap(
            currentLatitude,
            currentLongitude
        );

    }


    /* =========================================================
       GET CURRENT LOCATION
    ========================================================= */

    function getCurrentLocation() {

        if (
            !navigator.geolocation
        ) {

            console.warn(
                "Geolocation is not supported."
            );


            locationError({
                message:
                    "Geolocation not supported."
            });


            return;

        }


        navigator.geolocation.getCurrentPosition(

            function (position) {

                locationSuccess(
                    position
                );

            },

            function (error) {

                locationError(
                    error
                );

            },

            {
                enableHighAccuracy:
                    true,

                timeout:
                    10000,

                maximumAge:
                    0
            }

        );

    }


    /* =========================================================
       REFRESH LOCATION BUTTON
    ========================================================= */

    if (refreshLocationButton) {

        refreshLocationButton.addEventListener(
            "click",
            function () {

                /*
                 * Visual loading state
                 */

                this.classList.add(
                    "loading"
                );


                /*
                 * Check browser support
                 */

                if (
                    !navigator.geolocation
                ) {

                    locationError({
                        message:
                            "Geolocation not supported."
                    });


                    this.classList.remove(
                        "loading"
                    );


                    return;

                }


                navigator.geolocation.getCurrentPosition(

                    function (position) {

                        locationSuccess(
                            position
                        );


                        refreshLocationButton.classList.remove(
                            "loading"
                        );

                    },

                    function (error) {

                        locationError(
                            error
                        );


                        refreshLocationButton.classList.remove(
                            "loading"
                        );

                    },

                    {
                        enableHighAccuracy:
                            true,

                        timeout:
                            10000,

                        maximumAge:
                            0
                    }

                );

            }
        );

    }


    /* =========================================================
       SMOOTH SCROLL
    ========================================================= */

    const scrollLinks =
        document.querySelectorAll(
            'a[href^="#"]'
        );


    scrollLinks.forEach(function (link) {

        link.addEventListener(
            "click",
            function (event) {

                const targetId =
                    this.getAttribute("href");


                if (
                    !targetId ||
                    targetId === "#"
                ) {

                    return;

                }


                const target =
                    document.querySelector(
                        targetId
                    );


                if (target) {

                    event.preventDefault();


                    target.scrollIntoView({
                        behavior:
                            "smooth",

                        block:
                            "start"
                    });

                }

            }
        );

    });


    /* =========================================================
       ACTIVE SIDEBAR LINK
    ========================================================= */

    const currentPage =
        window.location.pathname;


    sidebarLinks.forEach(function (link) {

        try {

            const linkPath =
                new URL(
                    link.href,
                    window.location.origin
                ).pathname;


            if (
                linkPath === currentPage
            ) {

                sidebarLinks.forEach(
                    function (item) {

                        item.classList.remove(
                            "active"
                        );

                    }
                );


                link.classList.add(
                    "active"
                );

            }

        } catch (error) {

            console.warn(
                "Could not process sidebar link:",
                error
            );

        }

    });


    /* =========================================================
       BUTTON RIPPLE EFFECT
    ========================================================= */

    const buttons =
        document.querySelectorAll(
            ".gold-btn, .primary-btn, button"
        );


    buttons.forEach(function (button) {

        button.addEventListener(
            "click",
            function (event) {

                /*
                 * Don't create ripple if button
                 * is disabled.
                 */

                if (
                    button.disabled
                ) {
                    return;
                }


                const ripple =
                    document.createElement(
                        "span"
                    );


                ripple.classList.add(
                    "button-ripple"
                );


                const rect =
                    button.getBoundingClientRect();


                ripple.style.left =
                    (
                        event.clientX -
                        rect.left
                    ) + "px";


                ripple.style.top =
                    (
                        event.clientY -
                        rect.top
                    ) + "px";


                button.appendChild(
                    ripple
                );


                setTimeout(
                    function () {

                        ripple.remove();

                    },
                    600
                );

            }
        );

    });


    /* =========================================================
       WINDOW RESIZE
    ========================================================= */

    window.addEventListener(
        "resize",
        function () {

            /*
             * Close mobile sidebar
             */

            if (
                window.innerWidth > 991 &&
                sidebar
            ) {

                sidebar.classList.remove(
                    "active"
                );


                if (overlay) {

                    overlay.classList.remove(
                        "active"
                    );

                }

            }


            /*
             * Refresh Leaflet size
             */

            if (map) {

                setTimeout(
                    function () {

                        map.invalidateSize();

                    },
                    100
                );

            }

        }
    );


    /* =========================================================
       START GPS
    ========================================================= */

    getCurrentLocation();

});